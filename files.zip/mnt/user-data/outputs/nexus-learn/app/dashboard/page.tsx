"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { conversationsApi, documentsApi, testsApi } from "@/lib/api";
import type { Conversation, DocumentItem, TestSession } from "@/lib/types";

export default function DashboardPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [tests, setTests] = useState<TestSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      conversationsApi.list(),
      documentsApi.list(),
      testsApi.list(),
    ]).then(([c, d, t]) => {
      setConversations(c);
      setDocuments(d);
      setTests(t);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const submittedTests = tests.filter((t) => t.status === "SUBMITTED");
  const avgScore = submittedTests.length
    ? Math.round(
        submittedTests.reduce((a, t) => a + (t.scorePercentage ?? 0), 0) /
          submittedTests.length
      )
    : null;

  const recentConvos = conversations.slice(0, 4);
  const recentTests = tests.slice(0, 3);

  return (
    <div>
      {/* ── Header ── */}
      <header className="page-header">
        <div>
          <h1 className="page-title">Overview</h1>
          <p className="page-subtitle">Your learning at a glance</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Link href="/chat" className="btn btn-secondary btn-sm">
            New conversation
          </Link>
          <Link href="/tests" className="btn btn-primary btn-sm">
            Take a test
          </Link>
        </div>
      </header>

      <div className="page-body">
        {/* ── Stats ── */}
        <div className="stats-grid animate-fade-up">
          {[
            { value: conversations.length, label: "Conversations" },
            { value: documents.length, label: "Documents uploaded" },
            { value: tests.length, label: "Tests generated" },
            { value: avgScore != null ? `${avgScore}%` : "—", label: "Avg. score" },
          ].map((s, i) => (
            <div key={s.label} className={`stat-card animate-fade-up delay-${i + 1}`}>
              <div className="stat-value">{loading ? "—" : s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        {/* ── Two columns ── */}
        <div className="dash-grid">
          {/* Recent conversations */}
          <div className="card animate-fade-up delay-2">
            <div className="card-head">
              <h2 className="font-display card-title">Recent Conversations</h2>
              <Link href="/chat" className="card-link font-mono">
                View all →
              </Link>
            </div>
            <div className="card-body">
              {loading ? (
                <SkeletonList count={3} />
              ) : recentConvos.length === 0 ? (
                <EmptyState
                  icon="⟡"
                  text="No conversations yet"
                  action={{ href: "/chat", label: "Start one" }}
                />
              ) : (
                <ul className="item-list">
                  {recentConvos.map((c) => (
                    <li key={c.id}>
                      <Link href={`/chat/${c.id}`} className="item-row">
                        <div className="item-icon">⟡</div>
                        <div className="item-main">
                          <div className="item-title">{c.title}</div>
                          <div className="item-meta font-mono">
                            {new Date(c.updatedAt).toLocaleDateString()}
                          </div>
                        </div>
                        <span className={`badge badge-${c.difficultyLevel.toLowerCase()}`}>
                          {c.difficultyLevel}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Recent tests */}
          <div className="card animate-fade-up delay-3">
            <div className="card-head">
              <h2 className="font-display card-title">Recent Assessments</h2>
              <Link href="/tests" className="card-link font-mono">
                View all →
              </Link>
            </div>
            <div className="card-body">
              {loading ? (
                <SkeletonList count={3} />
              ) : recentTests.length === 0 ? (
                <EmptyState
                  icon="◇"
                  text="No assessments yet"
                  action={{ href: "/tests", label: "Generate one" }}
                />
              ) : (
                <ul className="item-list">
                  {recentTests.map((t) => (
                    <li key={t.id}>
                      <Link href={`/tests/${t.id}`} className="item-row">
                        <div className="item-icon">◇</div>
                        <div className="item-main">
                          <div className="item-title">{t.topic}</div>
                          <div className="item-meta font-mono">
                            {t.totalQuestions} questions
                          </div>
                        </div>
                        {t.status === "SUBMITTED" && t.scorePercentage != null ? (
                          <div
                            className="score-pill font-mono"
                            data-good={t.scorePercentage >= 60}
                          >
                            {Math.round(t.scorePercentage)}%
                          </div>
                        ) : (
                          <span className="badge" style={{ background: "rgba(88,120,192,0.15)", color: "var(--info)" }}>
                            IN PROGRESS
                          </span>
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* Documents strip */}
        <div className="card animate-fade-up delay-4" style={{ marginTop: 20 }}>
          <div className="card-head">
            <h2 className="font-display card-title">Documents</h2>
            <Link href="/documents" className="card-link font-mono">
              Manage →
            </Link>
          </div>
          <div className="card-body">
            {loading ? (
              <SkeletonList count={2} />
            ) : documents.length === 0 ? (
              <EmptyState
                icon="◈"
                text="No documents uploaded"
                action={{ href: "/documents", label: "Upload one" }}
              />
            ) : (
              <div className="docs-strip">
                {documents.map((d) => (
                  <div key={d.id} className="doc-chip">
                    <span className="doc-chip-icon">◈</span>
                    <div>
                      <div className="doc-chip-name">{d.originalFileName}</div>
                      <div className="doc-chip-size font-mono">
                        {formatBytes(d.fileSize)}
                      </div>
                    </div>
                    <span className={`badge badge-${d.status.toLowerCase()}`}>
                      {d.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 20px;
        }
        .dash-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }
        .card-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 22px 0;
        }
        .card-title {
          font-size: 18px;
          font-weight: 400;
          color: var(--cream);
          letter-spacing: -0.01em;
          margin: 0;
        }
        .card-link {
          font-size: 11px;
          letter-spacing: 0.06em;
          color: var(--gold-muted);
          text-decoration: none;
        }
        .card-link:hover { color: var(--gold-bright); }
        .card-body { padding: 16px 22px 20px; }
        .item-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 4px; }
        .item-row {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 12px;
          border-radius: var(--radius);
          text-decoration: none;
          transition: background 0.15s;
        }
        .item-row:hover { background: var(--bg-elevated); }
        .item-icon {
          width: 28px; height: 28px;
          background: var(--bg-overlay);
          border: 1px solid var(--border-subtle);
          border-radius: 6px;
          display: flex; align-items: center; justify-content: center;
          font-size: 12px;
          color: var(--gold-muted);
          flex-shrink: 0;
        }
        .item-main { flex: 1; min-width: 0; }
        .item-title {
          font-size: 13.5px;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .item-meta {
          font-size: 10px;
          color: var(--text-muted);
          letter-spacing: 0.04em;
          margin-top: 1px;
        }
        .score-pill {
          font-size: 11px;
          padding: 3px 8px;
          border-radius: 99px;
          font-weight: 500;
        }
        .score-pill[data-good="true"]  { background: rgba(92,158,106,0.15); color: var(--success); }
        .score-pill[data-good="false"] { background: rgba(192,88,88,0.15);  color: var(--error); }
        .docs-strip { display: flex; flex-direction: column; gap: 8px; }
        .doc-chip {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 12px;
          background: var(--bg-elevated);
          border-radius: var(--radius);
          border: 1px solid var(--border-subtle);
        }
        .doc-chip-icon { color: var(--gold-muted); font-size: 14px; }
        .doc-chip-name { font-size: 13px; color: var(--text-primary); }
        .doc-chip-size { font-size: 10px; color: var(--text-muted); letter-spacing: 0.04em; margin-top: 2px; }
        .doc-chip > :last-child { margin-left: auto; }

        @media (max-width: 1100px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 780px) { .dash-grid { grid-template-columns: 1fr; } }
      `}</style>
    </div>
  );
}

function SkeletonList({ count }: { count: number }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: "4px 0" }}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: 44, borderRadius: 8 }} />
      ))}
    </div>
  );
}

function EmptyState({
  icon, text, action,
}: {
  icon: string;
  text: string;
  action: { href: string; label: string };
}) {
  return (
    <div style={{ textAlign: "center", padding: "24px 0", color: "var(--text-muted)" }}>
      <div style={{ fontSize: 24, marginBottom: 8, opacity: 0.5 }}>{icon}</div>
      <div style={{ fontSize: 13, marginBottom: 12 }}>{text}</div>
      <Link href={action.href} className="btn btn-secondary btn-sm">
        {action.label}
      </Link>
    </div>
  );
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}
