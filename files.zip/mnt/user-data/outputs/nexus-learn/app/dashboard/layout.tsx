import { cookies } from "next/headers";
import Sidebar from "@/components/layout/Sidebar";

// In a real app, fetch user from server using the cookie
async function getUser() {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"}/api/auth/me`, {
      headers: { Cookie: cookies().toString() },
      cache: "no-store",
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.success ? json.data : null;
  } catch {
    return null;
  }
}

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getUser();

  return (
    <div className="app-layout">
      <Sidebar user={user} />
      <div className="main-content">{children}</div>
    </div>
  );
}
